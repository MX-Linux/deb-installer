<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="tr">
<context>
    <name>Installer</name>
    <message>
        <location filename="../src/installer.cpp" line="115"/>
        <location filename="../src/installer.cpp" line="238"/>
        <location filename="../src/installer.cpp" line="245"/>
        <location filename="../src/installer.cpp" line="253"/>
        <location filename="../src/installer.cpp" line="276"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="116"/>
        <source>Could not simulate the package installation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="169"/>
        <source>Remove</source>
        <translation>Kaldır</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="172"/>
        <location filename="../src/installer.cpp" line="206"/>
        <source>Install</source>
        <translation>Kur</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="178"/>
        <source>The following packages will be installed. Click &apos;Show Details...&apos; for information about the packages.</source>
        <translation>Aşağıdaki paketler kurulacaktır. Paketler hakkında bilgi edinmek için ‘Ayrıntıları Göster...’i tıklayın.</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="183"/>
        <source>File: %1</source>
        <translation>Dosya: %1</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="203"/>
        <source>Will install the following:</source>
        <translation>Aşağıdakiler kurulacak:</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="217"/>
        <source>Installing selected package, please authenticate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="239"/>
        <source>No privilege escalation tool found.
Please install pkexec or sudo.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="246"/>
        <source>No terminal emulator found.
Please install x-terminal-emulator.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="253"/>
        <source>Could not create an installation status file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="264"/>
        <source>Press any key to close</source>
        <translation>Kapatmak için herhangi bir tuşa basın</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="277"/>
        <source>Failed to launch the terminal emulator.
Please check that x-terminal-emulator is installed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="300"/>
        <location filename="../src/installer.cpp" line="304"/>
        <source>Package installation failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="301"/>
        <source>The package manager reported an error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="305"/>
        <source>Could not determine whether the installation succeeded.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="306"/>
        <source>The terminal closed unexpectedly before the installation result could be confirmed.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="55"/>
        <source>Program for installing Debian binary packages (deb files)</source>
        <translation>Debian binary paketlerini kurma programı (deb dosyaları)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="58"/>
        <source>files...</source>
        <translation>dosyalar...</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="58"/>
        <source>Name of .deb files to install</source>
        <translation>Kurulacak .deb dosyasının adı</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="59"/>
        <source>[file...]</source>
        <translation>[dosya...]</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>Select .deb files to install</source>
        <translation>Kurulacak .deb dosyolarını seçin</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>Deb Files (*.deb)</source>
        <translation>Deb Dosyaları (*.deb)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="90"/>
        <source>No .deb files were provided.</source>
        <translation>Hiç .deb dosyası sağlanmadı.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="98"/>
        <location filename="../src/main.cpp" line="102"/>
        <location filename="../src/main.cpp" line="107"/>
        <location filename="../src/main.cpp" line="112"/>
        <location filename="../src/main.cpp" line="117"/>
        <location filename="../src/main.cpp" line="126"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="98"/>
        <source>File %1 not found</source>
        <translation>%1 dosyası bulunamadı.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>File %1 is not a regular file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>File %1 is not readable.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Could not resolve the real path of %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>File %1 is not a .deb file.</source>
        <translation>%1 dosyası .deb dosyası değil.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>You must run this program as normal user.</source>
        <translation>Bu programı normal kullanıcı olarak çalıştırmalısınız.</translation>
    </message>
</context>
</TS>