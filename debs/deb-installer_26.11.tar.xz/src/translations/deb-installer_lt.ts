<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="lt">
<context>
    <name>Installer</name>
    <message>
        <location filename="../src/installer.cpp" line="117"/>
        <location filename="../src/installer.cpp" line="240"/>
        <location filename="../src/installer.cpp" line="247"/>
        <location filename="../src/installer.cpp" line="255"/>
        <location filename="../src/installer.cpp" line="278"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="118"/>
        <source>Could not simulate the package installation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="171"/>
        <source>Remove</source>
        <translation>Šalinti</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="174"/>
        <location filename="../src/installer.cpp" line="208"/>
        <source>Install</source>
        <translation>Įdiegti</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="180"/>
        <source>The following packages will be installed. Click &apos;Show Details...&apos; for information about the packages.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="185"/>
        <source>File: %1</source>
        <translation>Failas: %1</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="205"/>
        <source>Will install the following:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="219"/>
        <source>Installing selected package, please authenticate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="241"/>
        <source>No privilege escalation tool found.
Please install pkexec or sudo.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="248"/>
        <source>No terminal emulator found.
Please install x-terminal-emulator.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="255"/>
        <source>Could not create an installation status file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="266"/>
        <source>Press any key to close</source>
        <translation>Norėdami užverti, paspauskite bet kurį klavišą</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="279"/>
        <source>Failed to launch the terminal emulator.
Please check that x-terminal-emulator is installed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="318"/>
        <location filename="../src/installer.cpp" line="322"/>
        <source>Package installation failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="319"/>
        <source>The package manager reported an error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="323"/>
        <source>Could not determine whether the installation succeeded.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="324"/>
        <source>The terminal closed unexpectedly before the installation result could be confirmed.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="55"/>
        <source>Program for installing Debian binary packages (deb files)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="58"/>
        <source>files...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="58"/>
        <source>Name of .deb files to install</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="59"/>
        <source>[file...]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>Select .deb files to install</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>Deb Files (*.deb)</source>
        <translation>Deb failai (*.deb)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="90"/>
        <source>No .deb files were provided.</source>
        <translation>Nebuvo pateikta jokių .deb failų.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="98"/>
        <location filename="../src/main.cpp" line="102"/>
        <location filename="../src/main.cpp" line="107"/>
        <location filename="../src/main.cpp" line="112"/>
        <location filename="../src/main.cpp" line="117"/>
        <location filename="../src/main.cpp" line="126"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="98"/>
        <source>File %1 not found</source>
        <translation>Failas %1 nerastas</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>File %1 is not a regular file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>File %1 is not readable.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Could not resolve the real path of %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>File %1 is not a .deb file.</source>
        <translation>Failas %1 nėra .deb failas.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>You must run this program as normal user.</source>
        <translation>Privalote paleisti šią programą kaip normalus naudotojas.</translation>
    </message>
</context>
</TS>