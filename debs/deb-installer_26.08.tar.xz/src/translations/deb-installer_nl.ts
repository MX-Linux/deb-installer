<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nl">
<context>
    <name>Installer</name>
    <message>
        <location filename="../src/installer.cpp" line="114"/>
        <location filename="../src/installer.cpp" line="237"/>
        <location filename="../src/installer.cpp" line="244"/>
        <location filename="../src/installer.cpp" line="252"/>
        <location filename="../src/installer.cpp" line="274"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="115"/>
        <source>Could not simulate the package installation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="168"/>
        <source>Remove</source>
        <translation>Verwijder</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="171"/>
        <location filename="../src/installer.cpp" line="205"/>
        <source>Install</source>
        <translation>Installeer</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="177"/>
        <source>The following packages will be installed. Click &apos;Show Details...&apos; for information about the packages.</source>
        <translation>De volgende pakketten worden geïnstalleerd. Klik op &apos;Details Weergeven...&apos; voor informatie over de pakketten.</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="182"/>
        <source>File: %1</source>
        <translation>Bestand: %1</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="202"/>
        <source>Will install the following:</source>
        <translation>Zal het volgende installeren:</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="216"/>
        <source>Installing selected package, please authenticate</source>
        <translation>Geselecteerd pakket wordt geïnstalleerd, gelieve te verifiëren</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="238"/>
        <source>No privilege escalation tool found.
Please install pkexec or sudo.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="245"/>
        <source>No terminal emulator found.
Please install x-terminal-emulator.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="252"/>
        <source>Could not create an installation status file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="263"/>
        <source>Press any key to close</source>
        <translation>Druk een toets om te sluiten</translation>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="275"/>
        <source>Failed to launch the terminal emulator.
Please check that x-terminal-emulator is installed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="286"/>
        <source>Package installation failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/installer.cpp" line="287"/>
        <source>The package manager reported an error.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="55"/>
        <source>Program for installing Debian binary packages (deb files)</source>
        <translation>Programma voor het installeren van binaire pakketten van Debian (deb-bestanden)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="58"/>
        <source>files...</source>
        <translation>bestanden...</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="58"/>
        <source>Name of .deb files to install</source>
        <translation>Naam van .deb bestanden om te installeren</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="59"/>
        <source>[file...]</source>
        <translation>[bestand...]</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>Select .deb files to install</source>
        <translation>Selecteer .deb bestanden om te installeren</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>Deb Files (*.deb)</source>
        <translation>Deb Bestanden (*.deb)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="90"/>
        <source>No .deb files were provided.</source>
        <translation>Geen .deb-bestanden meegeleverd.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="98"/>
        <location filename="../src/main.cpp" line="102"/>
        <location filename="../src/main.cpp" line="107"/>
        <location filename="../src/main.cpp" line="112"/>
        <location filename="../src/main.cpp" line="117"/>
        <location filename="../src/main.cpp" line="126"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="98"/>
        <source>File %1 not found</source>
        <translation>Bestand %1 niet gevonden</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>File %1 is not a regular file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>File %1 is not readable.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>Could not resolve the real path of %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="118"/>
        <source>File %1 is not a .deb file.</source>
        <translation>Bestand %1 is geen .deb bestand.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="126"/>
        <source>You must run this program as normal user.</source>
        <translation>U moet dit programma als normale gebruiker uitvoeren.</translation>
    </message>
</context>
</TS>