/**********************************************************************
 *  main.cpp
 **********************************************************************
 * Copyright (C) 2022-2026 MX Authors
 *
 * Authors: Adrian
 *          MX Linux <http://mxlinux.org>
 *
 * This is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package. If not, see <http://www.gnu.org/licenses/>.
 **********************************************************************/

#include <QApplication>
#include <QCommandLineParser>
#include <QDebug>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QIcon>
#include <QLibraryInfo>
#include <QLocale>
#include <QMessageBox>
#include <QStandardPaths>
#include <QTranslator>

#include <memory>

#include "installer.h"
#include <unistd.h>

int main(int argc, char *argv[])
{
    const QByteArray option = argc == 2 ? QByteArray(argv[1]) : QByteArray();
    const bool informational = option == "-h" || option == "--help" || option == "--help-all"
                               || option == "-v" || option == "--version";
    std::unique_ptr<QCoreApplication> app;
    if (informational) {
        app = std::make_unique<QCoreApplication>(argc, argv);
    } else {
        if (qEnvironmentVariableIsEmpty("DISPLAY") && qEnvironmentVariableIsEmpty("WAYLAND_DISPLAY")
            && qEnvironmentVariableIsEmpty("QT_QPA_PLATFORM")) {
            qWarning("deb-installer: no display available (DISPLAY and WAYLAND_DISPLAY are both unset); "
                    "a graphical session is required to run this program.");
            return EXIT_FAILURE;
        }

        // Set Qt platform to XCB (X11) if not already set and we're in X11 environment
        if (qEnvironmentVariableIsEmpty("QT_QPA_PLATFORM") && !qEnvironmentVariableIsEmpty("DISPLAY")
            && qEnvironmentVariableIsEmpty("WAYLAND_DISPLAY")) {
            qputenv("QT_QPA_PLATFORM", "xcb");
        }

        app = std::make_unique<QApplication>(argc, argv);
    }

    QApplication::setOrganizationName("MX-Linux");
    QApplication::setApplicationVersion(VERSION);

    QCommandLineParser parser;
    parser.setApplicationDescription(QObject::tr("Program for installing Debian binary packages (deb files)"));
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addPositionalArgument(QObject::tr("files..."), QObject::tr("Name of .deb files to install"),
                                 QObject::tr("[file...]"));
    parser.process(*app);

    QApplication::setApplicationDisplayName("Deb Installer");
    QApplication::setWindowIcon(QIcon::fromTheme(QApplication::applicationName()));

    QTranslator qtTran;
    if (qtTran.load("qt_" + QLocale::system().name(), QLibraryInfo::path(QLibraryInfo::TranslationsPath))) {
        QApplication::installTranslator(&qtTran);
    }

    QTranslator qtBaseTran;
    if (qtBaseTran.load("qtbase_" + QLocale::system().name(), QLibraryInfo::path(QLibraryInfo::TranslationsPath))) {
        QApplication::installTranslator(&qtBaseTran);
    }

    QTranslator appTran;
    const QString appName = QApplication::applicationName();
    const QString localeDir = QStandardPaths::locate(QStandardPaths::GenericDataLocation,
                                                      appName + QStringLiteral("/locale"),
                                                      QStandardPaths::LocateDirectory);
    if (!localeDir.isEmpty()
        && appTran.load(appName + QStringLiteral("_") + QLocale::system().name(), localeDir)) {
        QApplication::installTranslator(&appTran);
    }

    if (getuid() != 0) {
        if (parser.positionalArguments().isEmpty()) {
            QStringList args = {"deb-installer"};
            args << QFileDialog::getOpenFileNames(nullptr, QObject::tr("Select .deb files to install"),
                                                  QDir::currentPath(), QObject::tr("Deb Files (*.deb)"));
            parser.process(args);
        }
        if (parser.positionalArguments().isEmpty()) {
            qDebug().noquote() << QObject::tr("No .deb files were provided.");
            return static_cast<int>(Installer::ExitCode::Cancelled);
        }
        const auto args = parser.positionalArguments();
        for (const auto &file : args) {
            const QFileInfo fileInfo(file);
            if (!fileInfo.exists()) {
                QApplication::beep();
                QMessageBox::critical(nullptr, QObject::tr("Error"), QObject::tr("File %1 not found").arg(file));
                return EXIT_FAILURE;
            } else if (!fileInfo.isFile()) {
                QApplication::beep();
                QMessageBox::critical(nullptr, QObject::tr("Error"),
                                      QObject::tr("File %1 is not a regular file.").arg(file));
                return EXIT_FAILURE;
            } else if (!fileInfo.isReadable()) {
                QApplication::beep();
                QMessageBox::critical(nullptr, QObject::tr("Error"),
                                      QObject::tr("File %1 is not readable.").arg(file));
                return EXIT_FAILURE;
            } else if (fileInfo.canonicalFilePath().isEmpty()) {
                QApplication::beep();
                QMessageBox::critical(nullptr, QObject::tr("Error"),
                                      QObject::tr("Could not resolve the real path of %1.").arg(file));
                return EXIT_FAILURE;
            } else if (!file.endsWith(".deb")) {
                QApplication::beep();
                QMessageBox::critical(nullptr, QObject::tr("Error"),
                                      QObject::tr("File %1 is not a .deb file.").arg(file));
                return EXIT_FAILURE;
            }
        }
        Installer installer;
        return static_cast<int>(installer.run(args));
    } else {
        QApplication::beep();
        QMessageBox::critical(nullptr, QObject::tr("Error"), QObject::tr("You must run this program as normal user."));
        return EXIT_FAILURE;
    }
}
