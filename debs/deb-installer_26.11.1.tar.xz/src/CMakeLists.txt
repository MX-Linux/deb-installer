# **********************************************************************
# * Copyright (C) 2022-2026 MX Authors
# *
# * Authors: Adrian
# *          MX Linux <http://mxlinux.org>
# *
# * This file is part of deb-installer.
# *
# * deb-installer is free software: you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation, either version 3 of the License, or
# * (at your option) any later version.
# *
# * deb-installer is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with deb-installer.  If not, see <http://www.gnu.org/licenses/>.
# **********************************************************************/

cmake_minimum_required(VERSION 3.16)

include(CheckCXXCompilerFlag)

# Option to use clang for testing builds - needs to be early so project() picks it up
option(USE_CLANG "Use clang compiler" OFF)
if(USE_CLANG)
    set(CMAKE_C_COMPILER clang CACHE STRING "C compiler" FORCE)
    set(CMAKE_CXX_COMPILER clang++ CACHE STRING "C++ compiler" FORCE)
    message(STATUS "Using clang compiler")
endif()

# Get version from debian/changelog
execute_process(
    COMMAND dpkg-parsechangelog -SVersion
    WORKING_DIRECTORY ${CMAKE_SOURCE_DIR}
    OUTPUT_VARIABLE PROJECT_VERSION_FROM_CHANGELOG
    OUTPUT_STRIP_TRAILING_WHITESPACE
    RESULT_VARIABLE DPKG_RESULT
)

# Fallback to a safe default when changelog parsing is unavailable
if(NOT DPKG_RESULT EQUAL 0 OR PROJECT_VERSION_FROM_CHANGELOG STREQUAL "")
    message(WARNING "Falling back to version 0.0.0 (dpkg-parsechangelog not available or failed)")
    set(PROJECT_VERSION_FROM_CHANGELOG "0.0.0")
endif()

project(deb-installer
    VERSION ${PROJECT_VERSION_FROM_CHANGELOG}
    DESCRIPTION "Deb Installer - Program for installing Debian binary packages (deb files)"
    LANGUAGES CXX
)

# Set C++ standard
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Enable compile commands export for IDEs and tools
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# Optimize for Ninja builds
if(CMAKE_GENERATOR STREQUAL "Ninja")
    # Enable colored output for Ninja
    if(CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
        add_compile_options(-fdiagnostics-color=always)
    elseif(CMAKE_CXX_COMPILER_ID STREQUAL "Clang")
        add_compile_options(-fcolor-diagnostics)
    endif()
endif()

# Option to use clang for testing builds
if(USE_CLANG)
    set(CMAKE_CXX_COMPILER_ID "Clang")
endif()

# Find Qt6 components
find_package(Qt6 REQUIRED COMPONENTS
    Core
    Gui
    Widgets
    LinguistTools
)

# Enable automatic MOC, UIC, and RCC processing
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTORCC ON)

# Define source files
set(SOURCES
    src/main.cpp
    src/cmd.cpp
    src/installer.cpp
)

set(HEADERS
    src/installer.h
    src/cmd.h
)

# Get all translation files
file(GLOB TRANSLATION_FILES "translations/*.ts")
list(FILTER TRANSLATION_FILES EXCLUDE REGEX "/deb-installer_en_US\\.ts$")

# Create the executable
add_executable(deb-installer
    ${SOURCES}
    ${HEADERS}
)

# Link Qt6 libraries
target_link_libraries(deb-installer
    Qt6::Core
    Qt6::Gui
    Qt6::Widgets
    acl
)

# Set compiler flags
target_compile_options(deb-installer PRIVATE
    -Wpedantic
    -pedantic
    -Werror=return-type
    -Werror=switch
    -Werror=uninitialized
    -Werror
)

# Add compiler-specific flags
if(CMAKE_CXX_COMPILER_ID STREQUAL "Clang" OR USE_CLANG)
    target_compile_options(deb-installer PRIVATE -Werror=return-stack-address)
else()
    target_compile_options(deb-installer PRIVATE -Werror=return-local-addr)
endif()

# Set compile definitions
target_compile_definitions(deb-installer PRIVATE
    QT_DEPRECATED_WARNINGS
    QT_DISABLE_DEPRECATED_BEFORE=0x060000
    VERSION="${PROJECT_VERSION}"
)

# Release-specific optimizations
if(CMAKE_BUILD_TYPE STREQUAL "Release")
    target_compile_definitions(deb-installer PRIVATE NDEBUG)
    target_compile_options(deb-installer PRIVATE -O3)

    # Add LTO - different flags for different compilers, with graceful fallback
    if(CMAKE_CXX_COMPILER_ID STREQUAL "Clang" OR USE_CLANG)
        check_cxx_compiler_flag(-flto=thin HAS_CLANG_LTO)
        if(HAS_CLANG_LTO)
            target_compile_options(deb-installer PRIVATE -flto=thin)
            target_link_options(deb-installer PRIVATE -flto=thin)
        endif()
    else()
        check_cxx_compiler_flag(-flto=auto HAS_GCC_LTO)
        if(HAS_GCC_LTO)
            target_compile_options(deb-installer PRIVATE -flto=auto)
            target_link_options(deb-installer PRIVATE -flto=auto)
        endif()
    endif()
endif()

# Handle translations
qt6_add_translations(deb-installer
    TS_FILES ${TRANSLATION_FILES}
    LRELEASE_OPTIONS -compress -nounfinished -removeidentical -silent
    QM_FILES_OUTPUT_VARIABLE qm_files
)

# Set target properties
set_target_properties(deb-installer PROPERTIES
    OUTPUT_NAME "deb-installer"
    RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}
)

# Tests (enabled by default; pass -DBUILD_TESTS=OFF to skip them)
option(BUILD_TESTS "Build unit tests" ON)
if(BUILD_TESTS)
    add_executable(deb-installer-tests
        tests/test_main.cpp
        src/cmd.cpp
        src/installer.cpp
    )
    target_include_directories(deb-installer-tests PRIVATE src)
    target_link_libraries(deb-installer-tests
        Qt6::Core
        Qt6::Gui
        Qt6::Widgets
        acl
    )
    target_compile_options(deb-installer-tests PRIVATE
        -Wpedantic
        -pedantic
        -Werror=return-type
        -Werror=switch
        -Werror=uninitialized
        -Werror
    )
    target_compile_definitions(deb-installer-tests PRIVATE
        QT_DEPRECATED_WARNINGS
        QT_DISABLE_DEPRECATED_BEFORE=0x060000
        VERSION="0.0.0-test"
    )
    set_target_properties(deb-installer-tests PROPERTIES
        AUTOMOC ON
        RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}
    )
    enable_testing()
    add_test(NAME deb-installer-tests COMMAND deb-installer-tests)
    add_test(NAME apt-install-wrapper-test
        COMMAND ${CMAKE_SOURCE_DIR}/tests/test_apt_install.sh ${CMAKE_SOURCE_DIR}/polkit/apt-install
    )
    add_executable(deb-installer-installation-tests
        tests/test_installation.cpp
        src/cmd.cpp
        src/installer.cpp
    )
    target_include_directories(deb-installer-installation-tests PRIVATE src)
    target_link_libraries(deb-installer-installation-tests Qt6::Widgets acl)
    target_compile_options(deb-installer-installation-tests PRIVATE -Wpedantic -Werror)
    add_test(NAME installation-monitor-test COMMAND deb-installer-installation-tests)
    add_test(NAME installation-snapshot-test COMMAND deb-installer-installation-tests --snapshot)
    add_test(NAME sudo-installation-test COMMAND deb-installer-installation-tests --sudo-snapshot)
    set_tests_properties(installation-monitor-test installation-snapshot-test sudo-installation-test PROPERTIES
        ENVIRONMENT "QT_QPA_PLATFORM=offscreen"
        TIMEOUT 60
    )
endif()

# Install target (required by Debian build system)
# Other files are handled by debian/install
install(TARGETS deb-installer
    RUNTIME DESTINATION bin
)
