<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="tr">
<context>
    <name>Installer</name>
    <message>
        <location filename="../installer.cpp" line="83"/>
        <source>Remove</source>
        <translation>Kaldır</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="86"/>
        <location filename="../installer.cpp" line="114"/>
        <source>Install</source>
        <translation>Kur</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="92"/>
        <source>The following packages will be installed. Click &apos;Show Details...&apos; for information about the packages.</source>
        <translation>Aşağıdaki paketler kurulacaktır. Paketler hakkında bilgi edinmek için ‘Ayrıntıları Göster...’i tıklayın.</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="97"/>
        <source>File: %1</source>
        <translation>Dosya: %1</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="111"/>
        <source>Will install the following:</source>
        <translation>Aşağıdakiler kurulacak:</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="123"/>
        <source>Installing selected package, please authenticate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../installer.cpp" line="128"/>
        <source>Press any key to close</source>
        <translation>Kapatmak için herhangi bir tuşa basın</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="46"/>
        <source>Program for installing Debian binary packages (deb files)</source>
        <translation>Debian binary paketlerini kurma programı (deb dosyaları)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="49"/>
        <source>files...</source>
        <translation>dosyalar...</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="49"/>
        <source>Name of .deb files to install</source>
        <translation>Kurulacak .deb dosyasının adı</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="50"/>
        <source>[file...]</source>
        <translation>[dosya...]</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="72"/>
        <source>Select .deb files to install</source>
        <translation>Kurulacak .deb dosyolarını seçin</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="73"/>
        <source>Deb Files (*.deb)</source>
        <translation>Deb Dosyaları (*.deb)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="77"/>
        <source>No .deb files were provided.</source>
        <translation>Hiç .deb dosyası sağlanmadı.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="84"/>
        <location filename="../main.cpp" line="88"/>
        <location filename="../main.cpp" line="96"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="84"/>
        <source>File %1 not found</source>
        <translation>%1 dosyası bulunamadı.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="89"/>
        <source>File %1 is not a .deb file.</source>
        <translation>%1 dosyası .deb dosyası değil.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="96"/>
        <source>You must run this program as normal user.</source>
        <translation>Bu programı normal kullanıcı olarak çalıştırmalısınız.</translation>
    </message>
</context>
</TS>