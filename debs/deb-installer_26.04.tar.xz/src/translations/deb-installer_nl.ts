<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nl">
<context>
    <name>Installer</name>
    <message>
        <location filename="../installer.cpp" line="83"/>
        <source>Remove</source>
        <translation>Verwijder</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="86"/>
        <location filename="../installer.cpp" line="114"/>
        <source>Install</source>
        <translation>Installeer</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="92"/>
        <source>The following packages will be installed. Click &apos;Show Details...&apos; for information about the packages.</source>
        <translation>De volgende pakketten worden geïnstalleerd. Klik op &apos;Details Weergeven...&apos; voor informatie over de pakketten.</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="97"/>
        <source>File: %1</source>
        <translation>Bestand: %1</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="111"/>
        <source>Will install the following:</source>
        <translation>Zal het volgende installeren:</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="123"/>
        <source>Installing selected package, please authenticate</source>
        <translation>Geselecteerd pakket wordt geïnstalleerd, gelieve te verifiëren</translation>
    </message>
    <message>
        <location filename="../installer.cpp" line="128"/>
        <source>Press any key to close</source>
        <translation>Druk een toets om te sluiten</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="46"/>
        <source>Program for installing Debian binary packages (deb files)</source>
        <translation>Programma voor het installeren van binaire pakketten van Debian (deb-bestanden)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="49"/>
        <source>files...</source>
        <translation>bestanden...</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="49"/>
        <source>Name of .deb files to install</source>
        <translation>Naam van .deb bestanden om te installeren</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="50"/>
        <source>[file...]</source>
        <translation>[bestand...]</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="72"/>
        <source>Select .deb files to install</source>
        <translation>Selecteer .deb bestanden om te installeren</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="73"/>
        <source>Deb Files (*.deb)</source>
        <translation>Deb Bestanden (*.deb)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="77"/>
        <source>No .deb files were provided.</source>
        <translation>Geen .deb-bestanden meegeleverd.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="84"/>
        <location filename="../main.cpp" line="88"/>
        <location filename="../main.cpp" line="96"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="84"/>
        <source>File %1 not found</source>
        <translation>Bestand %1 niet gevonden</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="89"/>
        <source>File %1 is not a .deb file.</source>
        <translation>Bestand %1 is geen .deb bestand.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="96"/>
        <source>You must run this program as normal user.</source>
        <translation>U moet dit programma als normale gebruiker uitvoeren.</translation>
    </message>
</context>
</TS>